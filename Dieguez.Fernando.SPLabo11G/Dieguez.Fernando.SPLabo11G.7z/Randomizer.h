#ifndef RANOMIZER_H_INCLUDED
#define RANOMIZER_H_INCLUDED

void startRandomizer();

char getRandomGender();

int getRandomNumber(int min, int max);
#endif // RANOMIZER_H_INCLUDED
