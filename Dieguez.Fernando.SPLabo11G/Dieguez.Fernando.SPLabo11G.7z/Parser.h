#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

int parser_PaisFromText(FILE* pFile, LinkedList* pArrayListPais);
int parser_PaisFromBinary(FILE* pFile, LinkedList* pArrayListPais);
#endif // PARSER_H_INCLUDED
